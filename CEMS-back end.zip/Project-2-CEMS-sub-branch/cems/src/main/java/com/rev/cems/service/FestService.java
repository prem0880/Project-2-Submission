package com.rev.cems.service;

import java.util.List;

import com.rev.cems.entity.Fest;


public interface FestService {
	public List<Fest> getAllFest();
	public Fest getFestById(Long id);
	public  Fest createFest(Fest fest,Long collegeId);
	public Fest updateFest(Long id,  Fest festUpdated);
	public Fest updateDate(Long id, String date); 
	public String deleteFest( Long id);
}
