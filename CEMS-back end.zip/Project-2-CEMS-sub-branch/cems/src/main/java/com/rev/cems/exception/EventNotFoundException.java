package com.rev.cems.exception;

public class EventNotFoundException extends RuntimeException {
	public EventNotFoundException(String msg) {
		super(msg);
	}
}
