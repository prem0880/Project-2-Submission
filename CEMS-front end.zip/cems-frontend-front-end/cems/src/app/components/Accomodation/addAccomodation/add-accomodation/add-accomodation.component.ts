import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {  Accomodation, AccomodationService } from 'src/app/services/Accomodation/accomodation.service';
import { AccomodationRequestService } from 'src/app/services/AccomodationRequest/accomodation-request.service';
import { Hostel, HostelserviceService } from 'src/app/services/hostelservice.service';

@Component({
  selector: 'app-add-accomodation',
  templateUrl: './add-accomodation.component.html',
  styleUrls: ['./add-accomodation.component.css']
})
export class AddAccomodationComponent implements OnInit {
  message?: string;
  hostel?:Hostel[];
  id?:any;
  accom?: any;

  constructor(private accomodationService:AccomodationService, private router :Router, private hostelService : HostelserviceService, private accomRequestService : AccomodationRequestService) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state as {
      id : any,
      accom : any
    };
    this.id = state.id;
    this.accom = state.accom;
    console.log(this.id);
   }
  ngOnInit(): void {
    this.getAllHostel();
  }
  onSubmit(addAccomodation:Accomodation):any{
    console.log(addAccomodation);
     addAccomodation.participants=this.id; 
     this.accomodationService.addAccomodations(addAccomodation).subscribe(data => {
     this.message=data;
      if(this.message=="Accomodation Created Successfully!"){
        this.accomRequestService.updateRequest(this.accom, "approved").subscribe((response)=>{
         window.alert(response);
        });
      }
    });
    this.router.navigate(["admin"]);
  }

  getAllHostel() {
    this.hostelService.getAllHostel().subscribe((response) => {
        this.hostel = response;
    });
  }
}
